package com.carinventory.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.carinventory.model.Car;

public class CarDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List saveEmployee() {
		String save = "select * from car";
		return jdbcTemplate.query(save, new RowMapper<Car>() {
			public Car mapRow(java.sql.ResultSet rs, int rowNum) throws SQLException {
				Car sp = new Car();
				sp.setCid(rs.getInt(1));
				sp.setMake(rs.getString(2));
				sp.setModel(rs.getString(3));
				sp.setYear(rs.getInt(4));
				sp.setSalesprice(rs.getInt(5));
				return sp;
			}
		});

	}
	public void insertCar(Car e) {

		jdbcTemplate.update("insert into car(cid,make,model,year,salesprice) values('" + e.getCid() + "','"
				+ e.getMake() + "','" + e.getModel() + "','" + e.getYear() + "','" + e.getSalesprice() + "')");

	}
}
