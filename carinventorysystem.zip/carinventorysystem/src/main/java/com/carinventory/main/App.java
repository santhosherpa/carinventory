package com.carinventory.main;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.carinventory.dao.CarDao;
import com.carinventory.model.Car;

public class App {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("bean.xml");
		CarDao cardao = (CarDao) ac.getBean("cardao");
		
		List<Car> saveEmployee = cardao.saveEmployee();
		Scanner s = new Scanner(System.in);
		System.out.println("Welcome to Mullet Joe's Gently Used Autos!");
        System.out.println("Please enter command add , list or quit : ");
		String make, model;
		int cid, salesprice, year;
		String cmd = s.nextLine();
		if (cmd.equals("quit")) {
			System.out.println("Good Bye!");
		} else if (cmd.equals("add")) {
			System.out.println("Please enter car's cid : ");
			cid = s.nextInt();
			System.out.println("Please enter car's make : ");
			make = s.next();
			System.out.println("Please enter car's model : ");
			model = s.next();
			System.out.println("Please enter car's year: ");
			year = s.nextInt();
			System.out.println("Please enter car's price : ");
			salesprice = s.nextInt();
			Car car = new Car();
			car.setCid(cid);
			car.setMake(make);
			car.setModel(model);
			car.setYear(year);
			car.setSalesprice(salesprice);
			cardao.insertCar(car);
           	} else if(cmd.equals("list"))  {
           		saveEmployee.forEach((z) -> System.out.println(z.getYear() + " " + z.getMake() + " " + z.getModel() + "  " + z.getSalesprice()));
           	}
		
		else {
			System.out.println("Please enter valid command");
	

		}
	}
}
